library(testthat)
library(pwr2ppl)

test_check("pwr2ppl")
